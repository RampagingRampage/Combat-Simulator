Combat Simulator 
is a simple and user-friendly simulator that allows you to simulate battles between your favorite superheroes, mythical gods, monsters, or any other characters you can imagine. The simulator comes with default characters and skills, but you can also create your own custom characters and skills to make the battles even more exciting.
You can load other lists I added by typing the trigger words: “scary”, “titan”, “xmen”, “mvp”,  and “dragonball”.
To view your custom characters during the simulation, make sure you place an image with the same name as the character into the “images” folder.

Creating Characters and Skills
The simulator allows you to create new characters and skills, but please note that these will not be saved long-term. If you want to use your characters or skills in the future, you will need to copy them into the htlm app.

Default Characters
The default characters in the simulator have been fine-tuned for optimal performance. However, other characters may be expanded in the future.

Permissions
The Combat Simulator is designed to be simple and use-friendly and without you needing to grant extra permissions.

Thank you for using checkign it out. I hope you enjoy creating exciting battles between your favorite characters.
-RampagingRam